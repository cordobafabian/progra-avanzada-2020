package interfazgrafica;

public class Main {

	public static void main(String[] args) {
		Visualizador frame = new Visualizador();
		frame.setVisible(true);
	}
}
